grisClaro = 'gray75'
grisMedio = 'gray25'
grisOscuro = 'gray10'